# config.py

class Config:
    SECRET_KEY = 'hard to secret key string'
    MAIL_SERVER = 'smtp.googlemail.com'
    MAIL_PORT = '587'
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'health3948@gmail.com'
    MAIL_PASSWORD = 'teamacd0412!'
    DB_HOST = '127.0.0.1'
    ORACLE_PORT = '1521'
    MYSQL_PORT = 3306
    MARIA_PORT = 3307
    ORACLE_USER = 'system'
    ORACLE_PW = 'tlsdbstjr1'
    MYSQL_USER = 'cadmin123'
    MYSQL_PW = 'admin123+'
    UPLOAD_FOLDER_PATH = 'app/uploads/upload_files'
    DOWNLOAD_FOLDER_PATH = 'app/uploads/download_files'
    #message broker url
    CELERY_BROKER_URL='redis://127.0.0.1:6379/0'
    #작업 저장할 백엔드 주소
    CELERY_RESULT_BACKEND='redis://127.0.0.1:6379/0'
    

    @staticmethod
    def init_app(app):
        pass



class DevelopmentConfig(Config):
    DEBUG = True


config = {
    'development' : DevelopmentConfig,
    'default' : DevelopmentConfig
}